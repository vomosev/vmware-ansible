# Setting up a PXEBoot Server on CentOS

# https://www.linuxtechi.com/configure-pxe-installation-server-centos-7/

yum install dhcp tftp tftp-server syslinux vsftpd xinetd

curl http://mirrors.melbourne.co.uk/sites/ftp.centos.org/centos/7.6.1810/isos/x86_64/CentOS-7-x86_64-Minimal-1810.iso -o /var/log/centos.iso

PXESERVER=172.16.1.17
PXEDHCPSTART=172.16.1.200
PXEDHCPFINISH=172.16.1.210
PXEGATEWAYIP=172.16.1.1
PXESUBNETIP=172.16.1.0
PXEBROADCASTIP=172.16.1.255
PXENETMASK=255.255.255.0
PXEDNSIP=8.8.8.8
PXEDOMAIN=pxeboot.local
PXEPWD=$(openssl passwd -1 Pxe@123#)

cat > /etc/dhcp/dhcpd.conf << EOF

# DHCP Server Configuration file.

ddns-update-style interim;
ignore client-updates;
authoritative;
allow booting;
allow bootp;
allow unknown-clients;

# internal subnet for my DHCP Server
subnet $PXESUBNETIP netmask $PXENETMASK {
range $PXEDHCPSTART $PXEDHCPFINISH;
option domain-name-servers $PXEDNSIP;
option domain-name $PXEDOMAIN;
option routers $PXEGATEWAYIP;
option broadcast-address $PXEBROADCASTIP;
default-lease-time 600;
max-lease-time 7200;

# IP of PXE Server
next-server $PXESERVER;
filename "pxelinux.0";
}

EOF

cat > /etc/xinetd.d/tftp << EOF
service tftp
{
 socket_type = dgram
 protocol    = udp
 wait        = yes
 user        = root
 server      = /usr/sbin/in.tftpd
 server_args = -s /var/lib/tftpboot
 disable     = no
 per_source  = 11
 cps         = 100 2
 flags       = IPv4
}
EOF

cp -v /usr/share/syslinux/pxelinux.0 /var/lib/tftpboot
cp -v /usr/share/syslinux/menu.c32 /var/lib/tftpboot
cp -v /usr/share/syslinux/memdisk /var/lib/tftpboot
cp -v /usr/share/syslinux/mboot.c32 /var/lib/tftpboot
cp -v /usr/share/syslinux/chain.c32 /var/lib/tftpboot

mkdir /var/lib/tftpboot/pxelinux.cfg
mkdir /var/lib/tftpboot/networkboot

mount -o loop /var/log/centos.iso /mnt/

cd /mnt/

cp -av * /var/ftp/pub/

cp /mnt/images/pxeboot/vmlinuz /var/lib/tftpboot/networkboot/
cp /mnt/images/pxeboot/initrd.img /var/lib/tftpboot/networkboot/

umount /mnt/

cat > /var/ftp/pub/centos7.cfg << EOF

#platform=x86, AMD64, or Intel EM64T
#version=DEVEL
# Firewall configuration
firewall --disabled
# Install OS instead of upgrade
install
# Use FTP installation media
url --url="ftp://$PXESERVER/pub/"
# Root password
rootpw --iscrypted $PXEPWD
# System authorization information
auth useshadow passalgo=sha512
# Use graphical install
graphical
firstboot disable
# System keyboard
keyboard us
# System language
lang en_US
# SELinux configuration
selinux disabled
# Installation logging level
logging level=info
# System timezone
timezone Europe/Amsterdam
# System bootloader configuration
bootloader location=mbr
clearpart --all --initlabel
part swap --asprimary --fstype="swap" --size=1024
part /boot --fstype xfs --size=300
part pv.01 --size=1 --grow
volgroup root_vg01 pv.01
logvol / --fstype xfs --name=lv_01 --vgname=root_vg01 --size=1 --grow
%packages
@^minimal
@core
%end
%addon com_redhat_kdump --disable --reserve-mb='auto'
%end

EOF

cat > /var/lib/tftpboot/pxelinux.cfg/default << EOF

default menu.c32
prompt 0
timeout 30
MENU TITLE LinuxTechi.com PXE Menu
LABEL centos7_x64
MENU LABEL CentOS 7_X64
KERNEL /networkboot/vmlinuz
APPEND initrd=/networkboot/initrd.img inst.repo=ftp://$PXESERVER/pub ks=ftp://$PXESERVER/pub/centos7.cfg

EOF

systemctl start xinetd
systemctl enable xinetd
systemctl start dhcpd.service
systemctl enable dhcpd.service

systemctl start vsftpd
systemctl enable vsftpd

# if selinux is enabled - setsebool -P allow_ftpd_full_access 1

firewall-cmd --add-service=ftp --permanent
firewall-cmd --add-service=dhcp --permanent
firewall-cmd --add-port=69/tcp --permanent 
firewall-cmd --add-port=69/udp --permanent 
firewall-cmd --add-port=4011/udp --permanent
firewall-cmd --reload
