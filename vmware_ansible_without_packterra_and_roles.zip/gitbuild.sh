sudo echo "#single-gcp" >> README.md
sudo git init
sudo git add *
sudo git commit -a -m "first commit"
sudo git remote add origin https://35.206.165.15/systems/single-gcp.git
sudo git push -u -f origin master
