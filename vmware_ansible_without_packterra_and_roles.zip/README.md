#vmware-ansible

The main files that launch everything are in the root folder.

Running the following command sets up the templates and builds the virtual machines

sh build-vmwaresite.sh CURRENTPASSWORD

#Folder Structure

The folders themselves follow a standard Ansible folder structure i.e. the following are standard folders

defaults
files
group_vars
host_vars - currently all variables are saved here in localhost.yml
roles
tasks
vars

Other folders such as serverdata are not Ansible standard and used to store information specific to the current implementation.