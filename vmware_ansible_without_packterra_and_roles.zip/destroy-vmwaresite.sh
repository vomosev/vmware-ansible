ansible-playbook -i inventory destroy-vmwaresite.yml -vvv --ask-become-pass -e "ansible_python_interpreter=/usr/local/bin/python3"
