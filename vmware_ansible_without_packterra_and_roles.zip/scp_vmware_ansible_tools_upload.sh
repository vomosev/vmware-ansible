scp -r -i ../single-gcp-key /var/www/html/vmware-ansible/ single-gcp@35.189.116.246:/var/www/html
