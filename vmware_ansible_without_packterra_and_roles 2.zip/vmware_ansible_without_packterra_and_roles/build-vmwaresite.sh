echo "Please supply an argument for VMPASSWORDSETTING"

echo "For instance 'sh build-vmwaresite.sh CURRENTPASSWORD'"

cd /var/www/html/vmware-ansible/packerterra/packer

cp /var/www/html/vmware-ansible/packerterra/packer/packer-builder-vsphere-iso.macos /usr/local/bin/

sudo chmod a+x /usr/local/bin/packer-builder-vsphere-iso.macos

sudo packer validate centos7.json

#packer build centos7.json

#ansible-playbook -i inventory build-vmwaresite.yml -vvv -e "VMPASSWORDSETTING=$1 ansible_python_interpreter=/usr/local/bin/python3" #--ask-become-pass
