sudo git config --global user.name "Victor Omos"
sudo git config --global user.email "vomosev@gmail.com"
sudo git add *
sudo git commit -a -m "Updating repository"
sudo git remote add origin http://172.16.1.24/vomosev/vmware-ansible.git
sudo git push -u -f origin dev
